var searchData=
[
  ['stddev_2ejava_0',['Stddev.java',['../Stddev_8java.html',1,'']]]
];
