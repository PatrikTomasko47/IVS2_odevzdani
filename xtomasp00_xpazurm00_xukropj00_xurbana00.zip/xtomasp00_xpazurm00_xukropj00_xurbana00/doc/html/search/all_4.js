var searchData=
[
  ['getfirst_0',['getFirst',['../classParser_1_1Pair.html#ab434012f7ca1c7a02d6fd61602bfb67b',1,'Parser::Pair']]],
  ['getformula_1',['getFormula',['../classParser_1_1Parser.html#a95c80cffff772573dd2c013311c6b101',1,'Parser::Parser']]],
  ['getsecond_2',['getSecond',['../classParser_1_1Pair.html#af85a795d6f649c38d5e7c6655687f9d9',1,'Parser::Pair']]]
];
