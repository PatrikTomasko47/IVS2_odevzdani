var searchData=
[
  ['helpwidow_0',['helpwidow',['../classGUI_1_1HelpWidow.html',1,'GUI.HelpWidow'],['../classGUI_1_1HelpWidow.html#aac15606f871e8b1263b899786c5bf803',1,'GUI.HelpWidow.HelpWidow()']]]
];
