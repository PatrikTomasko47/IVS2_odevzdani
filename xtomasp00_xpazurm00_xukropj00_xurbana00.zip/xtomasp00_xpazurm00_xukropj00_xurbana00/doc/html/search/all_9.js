var searchData=
[
  ['root_0',['root',['../classMath_1_1Library_1_1MathOperations.html#a3978f3eb95fd1f22139648f51b92ed94',1,'Math.Library.MathOperations.root(Integer x, Integer y)'],['../classMath_1_1Library_1_1MathOperations.html#a8257f146b9ab35cc7ea0936464463919',1,'Math.Library.MathOperations.root(Double x, Integer y)']]]
];
