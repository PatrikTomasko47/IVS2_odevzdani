var searchData=
[
  ['stddev_0',['Stddev',['../classStddev_1_1Stddev.html',1,'Stddev']]]
];
