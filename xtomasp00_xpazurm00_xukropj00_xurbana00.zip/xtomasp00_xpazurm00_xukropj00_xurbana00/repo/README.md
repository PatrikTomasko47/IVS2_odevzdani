Supported platform
------------------

Ubuntu 64bit

Authors
-------

Brno orloj fanclub
- xpazurm00 Marek Pazúr
- xtomasp00 Patrik Tomaško
- xukropj00 Jan Ukropec 
- xurbana00 Aleš Urbánek


License
-------
This software is distributed under the terms of the GNU General Public License v3.0.
