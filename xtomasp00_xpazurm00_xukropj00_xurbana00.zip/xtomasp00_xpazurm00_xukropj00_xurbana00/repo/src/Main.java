import GUI.MainWindow;

public class Main {
    public static void main(String[] args) {
        MainWindow.start();
    }
}
