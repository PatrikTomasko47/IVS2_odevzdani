/******************************************************
 * Název projektu: Calculator
 * Soubor: Pair.java
 * Poslední změna: 24.4.2024
 * Autor: xukropj00
 *
 * Popis: Třída na uchovávání dvojic proměnných
 *
 ******************************************************/
package Parser;

/**
 * @brief Class associating two variables of any data type together
 * @file Pair.java
 * @author Jan Ukropec [xukropj00]
 * @param <First>
 * @param <Second>
 */
public class Pair<First, Second> {
    private First first;
    private Second second;

    /**
     * Pair constructor
     * @param first
     * @param second
     */
    public Pair(First first, Second second) {
        this.first = first;
        this.second = second;
    }

    /**
     * @return first variable
     */
    public First getFirst(){
        return first;
    }

    /**
     * @return second variable
     */
    public Second getSecond(){
        return second;
    }
}
