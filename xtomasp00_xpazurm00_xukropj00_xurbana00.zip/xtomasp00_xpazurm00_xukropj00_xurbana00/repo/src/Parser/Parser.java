/******************************************************
 * Název projektu: Calculator
 * Soubor: Parser.java
 * Poslední změna: 24.4.2024
 * Autor: xukropj00
 *
 * Popis: Získávání dat ze řetězce obsahujícího matematickou rovnici
 *
 ******************************************************/
package Parser;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @file Parser.java
 * @author Jan Ukropec
 * @file Parser.java
 * @brief Class for parsing values from mathematical equations
 */
public class Parser {
    private final Pattern factorialPat = Pattern.compile("([0-9]+)!");
    private final Pattern powerPat = Pattern.compile("pow\\(([+-]?[0-9]+(?:\\.[0-9]+)?);([+]?[1-9][0-9]*)\\)");
    private final Pattern rootPat = Pattern.compile("root\\(([+-]?[0-9]+(?:\\.[0-9]+)?);([+]?[1-9][0-9]*)\\)");
    private final Pattern absoluteValuePat = Pattern.compile("abs\\(([+-]?[0-9]+(?:\\.[0-9]+)?)\\)");
    // Pattern for correct mathematical equation (including decimal numbers, power, root, factorial, absolute value, modulo, +-*/)
    private final Pattern equationPat = Pattern.compile("([+-]*(([0-9]+!)|((pow|root)\\([+-]*[0-9]+(\\.[0-9]+)?;[1-9][0-9]*\\))|(abs\\([+-]*[0-9]+(\\.[0-9]+)?\\))|([0-9]+(\\.[0-9]+)?)))(([+\\-*/%])([+-]*(([0-9]+!)|(abs\\([+-]*[0-9]+(\\.[0-9]+)?\\))|((pow|root)\\([+-]*[0-9]+(\\.[0-9]+)?;[1-9][0-9]*\\))|([0-9]+(\\.[0-9]+)?))))*");
    private final Pattern plusMinus = Pattern.compile("[+-]{2,}");
    private final Pattern doublePat = Pattern.compile("^[+-]?[0-9]+(\\.[0-9]+)?(E[0-9]+)?");
    private final Pattern operationPat = Pattern.compile("^[*/%]");

    private String currentFactorial;
    private String currentPower;
    private String currentRoot;
    private String currentAbsoluteValue;
    private String currentPlusMinus;
    private String formula;

    /**
     * @brief Removes spaces from the formula, replaces commas with dots
     * @param formula String with mathematical formula
     */
    public Parser(String formula) {
        this.formula = formula;
        this.formula = this.formula.replaceAll("\\s+", "");
        this.formula = this.formula.replace(',', '.');

        this.currentFactorial = "";
        this.currentPower = "";
        this.currentRoot = "";
        this.currentAbsoluteValue = "";
        this.currentPlusMinus = "";
    }

    /**
     * @brief Checks if string matches double pattern (uses comma as decimal point)
     * @param string
     * @return True: string matches double pattern False: otherwise
     */
    public static boolean isDouble(String string){
        Matcher matcher = Pattern.compile("^[+-]?[0-9]+(,[0-9]+)?$").matcher(string);
        return matcher.matches();
    }

    /**
     * @brief Seeks next factorial in the fomula
     * @return Factorial input value or -1 if any factorial was not found
     */
    public int findFactorial(){
        Matcher matcher = factorialPat.matcher(formula);
        if(matcher.find()){
            this.currentFactorial = Pattern.quote(matcher.group());
            return Integer.parseInt(matcher.group(1));
        }
        return -1;
    }

    /**
     * @brief Substitutes all factorials in the equation, matching the previously found one
     * If no factorial has been found yet, nothing will happen
     * @param value Value to substitute the factorials with
     */
    public void subFactorial(Integer value){
        if(this.currentFactorial.isEmpty()){
            return;
        }
        this.formula = this.formula.replaceAll(this.currentFactorial, String.valueOf(value));
        this.currentFactorial = "";
    }
    /**
     * @brief Seeks next power in the fomula
     * @return Pair consisting of base (Double) and exponent (Integer) or null if any power was not found
     */
    public Pair<Double, Integer> findPower(){
        Matcher matcher = powerPat.matcher(formula);
        if(matcher.find()){
            this.currentPower = Pattern.quote(matcher.group());
            return new Pair<Double, Integer>(Double.parseDouble(matcher.group(1)), Integer.parseInt(matcher.group(2)));
        }
        return null;
    }
    /**
     * @brief Substitutes all powers in the equation, matching the previously found one
     * If no power has been found yet, nothing will happen
     * @param value Value to substitute the powers with
     */
    public void subPower(Double value){
        if(this.currentPower.isEmpty()){
            return;
        }
        this.formula = this.formula.replaceAll(this.currentPower, String.valueOf(value));
        this.currentPower = "";
    }
    /**
     * @brief Seeks next root in the fomula
     * @return Pair consisting of base (Double) and exponent(1/e) (Integer) or null if any power is not found
     */
    public Pair<Double, Integer> findRoot(){
        Matcher matcher = rootPat.matcher(formula);
        if(matcher.find()){
            this.currentRoot = Pattern.quote(matcher.group());
            return new Pair<Double, Integer>(Double.parseDouble(matcher.group(1)), Integer.parseInt(matcher.group(2)));
        }
        return null;
    }
    /**
     * @brief Substitutes all roots in the equation, matching the previously found one
     * If no power has been found yet, nothing will happen
     * @param value Value to substitute the roots with
     */
    public void subRoot(Double value){
        if(this.currentRoot.isEmpty()){
            return;
        }
        this.formula = this.formula.replaceAll(this.currentRoot, String.valueOf(value));
        this.currentRoot = "";
    }
    /**
     * @brief Seeks next absolute value in the fomula
     * @return Absolute value input value or null if any absolute value is not found
     */
    public Double findAbsoluteValue(){
        Matcher matcher = absoluteValuePat.matcher(formula);
        if(matcher.find()){
            this.currentAbsoluteValue = Pattern.quote(matcher.group());
            return Double.parseDouble(matcher.group(1));
        }
        return null;
    }
    /**
     * @brief Substitutes all absolute values in the equation, matching the previously found one
     * If no absolute value has been found yet, nothing will happen
     * @param value Value to substitute the roots with
     */
    public void subAbsoluteValue(Double value){
        if(this.currentAbsoluteValue.isEmpty()){
            return;
        }
        this.formula = this.formula.replaceAll(this.currentAbsoluteValue, String.valueOf(value));
        this.currentAbsoluteValue = "";
    }

    /**
     * @brief Seeks the next sequence of pluses and minuses in the formula
     * @return The sequence or null if any is not found
     */
    public String findPlusMinus(){
        Matcher matcher = plusMinus.matcher(formula);
        if(matcher.find()){
            this.currentPlusMinus = Pattern.quote(matcher.group());
            return matcher.group();
        }
        return null;
    }

    /**
     * @brief Replaces all plus and minus sequences like the last found with value
     * If no sequence has been found yet, nothing happens
     * @param value
     */
    public void subPlusMinus(String value){
        if(this.currentPlusMinus.isEmpty()){
            return;
        }
        this.formula = this.formula.replaceAll(this.currentPlusMinus, value);
        this.currentPlusMinus = "";
    }

    /**
     * @brief Checks if the formula matches formulaPat
     * @return True: matches, False: does not match
     */
    public boolean isEquation(){
        Matcher matcher = equationPat.matcher(formula);
        return matcher.matches();
    }

    /**
     * @brief Finds the first Double in the formula and replaces it with an empty string
     * @return Found Double or null if any was not found
     */
    public Double popNextDouble(){
        Matcher matcher = doublePat.matcher(formula);
        if(matcher.find()){
            this.formula = matcher.replaceFirst("");
            return Double.parseDouble(matcher.group());
        }
        return null;
    }

    /**
     * @brief Checks if the first character in the formula is %/*
     * @return True: First char. is %/*, False: Other or no character
     */
    public boolean isNextOperation(){
        Matcher matcher = operationPat.matcher(formula);
        return matcher.find();
    }

    /**
     * @brief Replaces the first character in the formula if it is %/*
     * @return String containing %/* or null if the formula does not begin with %/*
     */
    public String popNextOperation(){
        Matcher matcher = operationPat.matcher(formula);
        if(matcher.find()){
            this.formula = matcher.replaceFirst("");
            return matcher.group();
        }
        return null;
    }

    /**
     * @brief Converts double value to string, without exponent and with comma as a decimal point
     * @param value
     * @return string containing double
     */
    public static String doubleToString(Double value){
        DecimalFormat df = new DecimalFormat("#.########");
        return df.format(value).replace('.', ',');
    }

    /**
     * @brief Returns formula, with dots replaced with commas
     * @return formula
     */
    public String getFormula(){
        return this.formula.replace('.', ',');
    }
}
