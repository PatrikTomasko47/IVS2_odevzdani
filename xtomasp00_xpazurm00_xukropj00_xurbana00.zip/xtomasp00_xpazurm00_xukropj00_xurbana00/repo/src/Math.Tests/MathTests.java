package Math.Tests;

import Math.Library.Constants;
import Math.Library.MathOperations;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MathTests {
    @Test
    public void addIntegerTest() {
        assertEquals((Integer) 0, MathOperations.add(0, 0));
        assertEquals((Integer) 0, MathOperations.add(1, -1));
        assertEquals((Integer) 0, MathOperations.add(-1, 1));

        assertEquals((Integer) 1, MathOperations.add(0, 1));
        assertEquals((Integer) 1, MathOperations.add(1, 0));

        assertEquals((Integer) 2, MathOperations.add(1, 1));

        assertEquals((Integer) 1000, MathOperations.add(750, 250));
        assertEquals((Integer) (-1000), MathOperations.add(-750, -250));

        assertEquals((Integer) 123456, MathOperations.add(120000, 3456));
        assertEquals((Integer) 12, MathOperations.add((1 + 1 + 1 + 1 + 1 + 1), (1 + 1 + 1 + 1 + 1 + 1)));

        assertEquals((Integer) 777, (Integer) (MathOperations.add(700, 70) + MathOperations.add(0, 7)));
    }

    @Test
    public void addDoubleTest() {
        assertEquals(0.0, MathOperations.add(0.0, 0.0), Constants.EPSILON);
        assertEquals(0.0, MathOperations.add(1.0, -1.0), Constants.EPSILON);
        assertEquals(0.0, MathOperations.add(-1.0, 1.0), Constants.EPSILON);

        assertEquals(1.0, MathOperations.add(0.0, 1.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.add(1.0, 0.0), Constants.EPSILON);

        assertEquals(2.0, MathOperations.add(1.0, 1.0), Constants.EPSILON);

        assertEquals(1000.1000, MathOperations.add(750.0750, 250.0250), Constants.EPSILON);
        assertEquals(-1000.1000, MathOperations.add(-750.0750, -250.0250), Constants.EPSILON);

        assertEquals(Constants.PI, MathOperations.add(2.141592653589793, 1.0), Constants.EPSILON);
        assertEquals(Constants.PI, MathOperations.add(0.000000003589793, 3.14159265), Constants.EPSILON);

        assertEquals(Constants.PI * 2, MathOperations.add(Constants.PI, Constants.PI), Constants.EPSILON);
        assertEquals(Constants.E * 2, MathOperations.add(Constants.E, Constants.E), Constants.EPSILON);
        assertEquals(Constants.E + Constants.PI, MathOperations.add(Constants.E, Constants.PI), Constants.EPSILON);
    }

    @Test
    public void subIntegerTest() {
        assertEquals((Integer) 0, MathOperations.sub(0, 0));
        assertEquals((Integer) 0, MathOperations.sub(1, 1));

        assertEquals((Integer) (-1), MathOperations.sub(0, 1));
        assertEquals((Integer) 1, MathOperations.sub(1, 0));

        assertEquals((Integer) 2, MathOperations.sub(1, -1));
        assertEquals((Integer) (-2), MathOperations.sub(-1, 1));

        assertEquals((Integer) 0, MathOperations.sub(-1, -1));

        assertEquals((Integer) 500, MathOperations.sub(750, 250));
        assertEquals((Integer) (-500), MathOperations.sub(-750, -250));

        assertEquals((Integer) 0, MathOperations.sub((1 + 1 + 1 + 1 + 1 + 1), (1 + 1 + 1 + 1 + 1 + 1)));

        assertEquals((Integer) 623, (Integer) (MathOperations.sub(700, 70) + MathOperations.sub(0, 7)));
    }

    @Test
    public void subDoubleTest() {
        assertEquals(0.0, MathOperations.sub(0.0, 0.0), Constants.EPSILON);
        assertEquals(2.0, MathOperations.sub(1.0, -1.0), Constants.EPSILON);
        assertEquals((-2.0), MathOperations.sub(-1.0, 1.0), Constants.EPSILON);

        assertEquals((-1.0), MathOperations.sub(0.0, 1.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.sub(1.0, 0.0), Constants.EPSILON);

        assertEquals(0.0, MathOperations.sub(1.0, 1.0), Constants.EPSILON);
        assertEquals(0.0, MathOperations.sub(-1.0, -1.0), Constants.EPSILON);

        assertEquals(500.0500, MathOperations.sub(750.0750, 250.0250), Constants.EPSILON);
        assertEquals(-500.0500, MathOperations.sub(-750.0750, -250.0250), Constants.EPSILON);

        assertEquals(1.141592653589793, MathOperations.sub(2.141592653589793, 1.0), Constants.EPSILON);

        assertEquals(0.0, MathOperations.sub(Constants.PI, Constants.PI), Constants.EPSILON);
        assertEquals(0.0, MathOperations.sub(Constants.E, Constants.E), Constants.EPSILON);
        assertEquals(Constants.E - Constants.PI, MathOperations.sub(Constants.E, Constants.PI), Constants.EPSILON);
    }

    @Test
    public void mulIntegerTest() {
        assertEquals((Integer) 0, MathOperations.mul(0, 0));
        assertEquals((Integer) (-1), MathOperations.mul(1, -1));
        assertEquals((Integer) (-1), MathOperations.mul(-1, 1));
        assertEquals((Integer) 0, MathOperations.mul(0, 1));
        assertEquals((Integer) 0, MathOperations.mul(1, 0));
        assertEquals((Integer) 1, MathOperations.mul(1, 1));
        assertEquals((Integer) 1, MathOperations.mul(-1, -1));

        assertEquals((Integer) 100, MathOperations.mul(10, 10));
        assertEquals((Integer) 333, MathOperations.mul(111, 3));
        assertEquals((Integer) 56088, MathOperations.mul(123, 456));

        assertEquals((Integer) (-64), MathOperations.mul(8, -8));
    }

    @Test
    public void mulDoubleTest() {
        assertEquals(0.0, MathOperations.mul(0.0, 0.0), Constants.EPSILON);
        assertEquals(-1.0, MathOperations.mul(1.0, -1.0), Constants.EPSILON);
        assertEquals(-1.0, MathOperations.mul(-1.0, 1.0), Constants.EPSILON);
        assertEquals(0.0, MathOperations.mul(0.0, 1.0), Constants.EPSILON);
        assertEquals(0.0, MathOperations.mul(1.0, 0.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.mul(1.0, 1.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.mul(-1.0, -1.0), Constants.EPSILON);

        assertEquals(100.0, MathOperations.mul(-10.0, -10.0), Constants.EPSILON);
        assertEquals(56311.121088, MathOperations.mul(123.456, 456.123), Constants.EPSILON);
        assertEquals(Constants.PI * Constants.E, MathOperations.mul(Constants.PI, Constants.E), Constants.EPSILON);
    }

    @Test
    public void divIntegerTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.div(0, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.div(1, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.div(1234567890, 0));

        assertEquals( 1.0, MathOperations.div(1, 1));
        assertEquals( -1.0, MathOperations.div(1, -1));
        assertEquals(-1.0, MathOperations.div(-1, 1));
        assertEquals(1.0, MathOperations.div(-1, -1));

        assertEquals(3+(1.0/3.0), MathOperations.div(10, 3));
        assertEquals(0.5, MathOperations.div(1, 2));
        assertEquals(0.25, MathOperations.div(1, 4));

        assertEquals(25.0, MathOperations.div(50, 2));
        assertEquals(-333-(1.0/3.0), MathOperations.div(1000, -3));
        assertEquals(0.0, MathOperations.div(0, 123));
        assertEquals(1.0, MathOperations.div(123, 123));
        assertEquals(11.0, MathOperations.div(121, 11));
    }

    @Test
    public void divDoubleTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.div(0.0, 0.0));
        assertThrows(ArithmeticException.class, () -> MathOperations.div(1.111, 0.0));
        assertThrows(ArithmeticException.class, () -> MathOperations.div(123.456789, 0.0));

        assertEquals(1.0, MathOperations.div(1.0, 1.0), Constants.EPSILON);
        assertEquals(-1.0, MathOperations.div(1.0, -1.0), Constants.EPSILON);
        assertEquals(-1.0, MathOperations.div(-1.0, 1.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.div(-1.0, -1.0), Constants.EPSILON);

        assertEquals(2.0, MathOperations.div(Constants.PI * 2.0, Constants.PI), Constants.EPSILON);
        assertEquals(1.0, MathOperations.div(Constants.PI, Constants.PI), Constants.EPSILON);

        assertEquals(3.07680373832, MathOperations.div(987.654, 321.000), Constants.EPSILON);
        assertEquals(11.0, MathOperations.div(121.0, 11.0), Constants.EPSILON);
        assertEquals(3.3333333333333333, MathOperations.div(10.0, 3.0), Constants.EPSILON);

    }

    @Test
    public void factorialTest() {
        assertEquals((Integer) 1, MathOperations.factorial(0));
        assertEquals((Integer) 1, MathOperations.factorial(-1));

        assertEquals((Integer) 1, MathOperations.factorial(1));
        assertEquals((Integer) 2, MathOperations.factorial(2));
        assertEquals((Integer) 6, MathOperations.factorial(3));
        assertEquals((Integer) 24, MathOperations.factorial(4));
        assertEquals((Integer) 120, MathOperations.factorial(5));
        assertEquals((Integer) 720, MathOperations.factorial(6));
        assertEquals((Integer) 5040, MathOperations.factorial(7));
        assertEquals((Integer) 40320, MathOperations.factorial(8));
        assertEquals((Integer) 362880, MathOperations.factorial(9));
        assertEquals((Integer) 3628800, MathOperations.factorial(10));
    }

    @Test
    public void powerIntegerTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.power(2, -1));
        assertThrows(ArithmeticException.class, () -> MathOperations.power(2, -10));

        assertEquals((Integer) 1, MathOperations.power(0, 0));
        assertEquals((Integer) 1, MathOperations.power(10, 0));
        assertEquals((Integer) 10, MathOperations.power(10, 1));

        assertEquals((Integer) 25, MathOperations.power(5, 2));

        assertEquals((Integer) 1, MathOperations.power(2, 0));
        assertEquals((Integer) 2, MathOperations.power(2, 1));
        assertEquals((Integer) 4, MathOperations.power(2, 2));
        assertEquals((Integer) 8, MathOperations.power(2, 3));
        assertEquals((Integer) 16, MathOperations.power(2, 4));
        assertEquals((Integer) 32, MathOperations.power(2, 5));
        assertEquals((Integer) 64, MathOperations.power(2, 6));
        assertEquals((Integer) 128, MathOperations.power(2, 7));
        assertEquals((Integer) 256, MathOperations.power(2, 8));

        assertEquals((Integer) 65536, MathOperations.power(2, 16));
    }

    @Test
    public void powerDoubleTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.power(2.0, -1));
        assertThrows(ArithmeticException.class, () -> MathOperations.power(2.0, -10));

        assertEquals(1.0, MathOperations.power(0.0, 0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.power(10.0, 0), Constants.EPSILON);
        assertEquals(10.0, MathOperations.power(10.0, 1), Constants.EPSILON);
        assertEquals(25.0, MathOperations.power(5.0, 2), Constants.EPSILON);

        assertEquals(1.0, MathOperations.power(123.456, 0), Constants.EPSILON);
        assertEquals(123.456, MathOperations.power(123.456, 1), Constants.EPSILON);
        assertEquals(15241.383936, MathOperations.power(123.456, 2), Constants.EPSILON);

        assertEquals(Constants.PI * Constants.PI * Constants.PI, MathOperations.power(Constants.PI, 3), Constants.EPSILON);

    }

    @Test
    public void rootIntegerTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.root(-3, 2));

        assertThrows(ArithmeticException.class, () -> MathOperations.root(1, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.root(2, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.root(3, 0));

        assertEquals(1.0, MathOperations.root(1, 1), Constants.EPSILON);
        assertEquals(1.0, MathOperations.root(1, 2), Constants.EPSILON);

        assertEquals(1.41421356237, MathOperations.root(2, 2), Constants.EPSILON);

        assertEquals(4.0, MathOperations.root(4, 1), Constants.EPSILON);
        assertEquals(2.0, MathOperations.root(4, 2), Constants.EPSILON);
        assertEquals(0.5, MathOperations.root(4, -2), Constants.EPSILON);

        assertEquals(2.0, MathOperations.root(8, 3), Constants.EPSILON);
        assertEquals(0.5, MathOperations.root(8, -3), Constants.EPSILON);
    }

    @Test
    public void rootDoubleTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.root(-0.2, 2));

        assertThrows(ArithmeticException.class, () -> MathOperations.root(0.1, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.root(0.2, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.root(0.3, 0));

        assertEquals(1.5, MathOperations.root(2.25, 2), Constants.EPSILON);
        assertEquals(1.5, MathOperations.root(3.375, 3), Constants.EPSILON);

        assertEquals(Constants.PI, MathOperations.root(Constants.PI * Constants.PI, 2), Constants.EPSILON);
        assertEquals(Constants.E, MathOperations.root(Constants.E * Constants.E, 2), Constants.EPSILON);

        assertEquals(0.44444444444444, MathOperations.root(5.0625, -2), Constants.EPSILON);

        assertEquals(11.111075555499, MathOperations.root(123.456, 2), Constants.EPSILON);
        assertEquals(3.3333279999872, MathOperations.root(123.456, 4), Constants.EPSILON);
    }

    @Test
    public void absIntegerTest() {
        assertEquals((Integer) 0, MathOperations.abs(0));
        assertEquals((Integer) 1, MathOperations.abs(1));
        assertEquals((Integer) 1, MathOperations.abs(-1));

        assertEquals((Integer) 777, MathOperations.abs(777));
        assertEquals((Integer) 123, MathOperations.abs(-123));
    }

    @Test
    public void absDoubleTest() {
        assertEquals(0.0, MathOperations.abs(0.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.abs(1.0), Constants.EPSILON);
        assertEquals(1.0, MathOperations.abs(-1.0), Constants.EPSILON);

        assertEquals(777.0, MathOperations.abs(777.0), Constants.EPSILON);
        assertEquals(123.0, MathOperations.abs(-123.0), Constants.EPSILON);
    }

    @Test
    public void modIntegerTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(0, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(1, 0));
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(1234567890, 0));

        assertEquals((Integer) 0, MathOperations.mod(1, 1));
        assertEquals((Integer) 0, MathOperations.mod(0, 1));

        assertEquals((Integer) 0, MathOperations.mod(5, 1));
        assertEquals((Integer) 1, MathOperations.mod(5, 2));
        assertEquals((Integer) 2, MathOperations.mod(5, 3));
        assertEquals((Integer) 1, MathOperations.mod(5, 4));
        assertEquals((Integer) 0, MathOperations.mod(5, 5));

        assertEquals((Integer) 456, MathOperations.mod(123456, 1000));
    }

    @Test
    public void modDoubleTest() {
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(0.0, 0.0));
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(1.0, 0.0));
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(1.111, 0.0));
        assertThrows(ArithmeticException.class, () -> MathOperations.mod(123.456789, 0.0));

        assertEquals(0.0, MathOperations.mod(1.0, 1.0), Constants.EPSILON);
        assertEquals(0.0, MathOperations.mod(0.0, 1.0), Constants.EPSILON);

        assertEquals(Constants.PI % Constants.E, MathOperations.mod(Constants.PI, Constants.E), Constants.EPSILON);
        assertEquals(0.0, MathOperations.mod(Constants.PI, Constants.PI), Constants.EPSILON);
        assertEquals(0.0, MathOperations.mod(Constants.E, Constants.E), Constants.EPSILON);
        assertEquals(0.41421356237, MathOperations.mod(1.41421356237, 1.0), Constants.EPSILON);
        assertEquals(1.41421356237, MathOperations.mod(1.41421356237, 2.0), Constants.EPSILON);
        assertEquals(0.63721356237, MathOperations.mod(1.41421356237, 0.777), Constants.EPSILON);

    }
}
