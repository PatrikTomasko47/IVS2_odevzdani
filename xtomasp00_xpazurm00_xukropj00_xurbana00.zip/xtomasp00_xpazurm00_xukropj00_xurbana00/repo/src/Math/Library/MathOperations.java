/********************************************
 * Název projektu: Calculator
 * Balíček: Math.Library
 * Soubor: MathOperations.java
 * Datum: 27.3.2024
 * Poslední  změna: 17.4.2024
 * Autor: xurbana00 & xpazurm00
 *
 * Popis: Matematická knihovna
 *
 ********************************************/
/**
 * @file MathOperations.java
 *
 * @brief Math library for calculations
 * @author xurbana00 & xpazurm00
 */
package Math.Library;

public class MathOperations {

    /**
     * Adds two integers.
     * @param x The first addend.
     * @param y The second addend.
     * @return The sum of x and y.
     */
    public static Integer add(Integer x, Integer y) {
        return add(x.doubleValue(), y.doubleValue()).intValue();
    }

    /**
     * Adds an integer and a decimal number.
     * @param x The first addend.
     * @param y The second addend.
     * @return The sum of x and y.
     */
    public static Double add(Integer x, Double y) {
        return add(x.doubleValue(), y);
    }

    /**
     * Adds a decimal number and an integer.
     * @param x The first addend.
     * @param y The second addend.
     * @return The sum of x and y.
     */
    public static Double add(Double x, Integer y) {
        return add(x, y.doubleValue());
    }

    /**
     * Adds two decimal numbers.
     * @param x The first addend.
     * @param y The second addend.
     * @return The sum of x and y.
     */
    public static Double add(Double x, Double y) {
        return x + y;
    }

    /**
     * Subtracts two integers.
     * @param x The minuend.
     * @param y The subtrahend.
     * @return The difference of x and y.
     */
    public static Integer sub(Integer x, Integer y) {
        return sub(x.doubleValue(), y.doubleValue()).intValue();
    }

    /**
     * Subtracts a decimal number from an integer.
     * @param x The minuend.
     * @param y The subtrahend.
     * @return The difference of x and y.
     */
    public static Double sub(Integer x, Double y) {
        return sub(x.doubleValue(), y);
    }

    /**
     * Subtracts an integer from a decimal number.
     * @param x The minuend.
     * @param y The subtrahend.
     * @return The difference of x and y.
     */
    public static Double sub(Double x, Integer y) {
        return sub(x, y.doubleValue());
    }

    /**
     * Subtracts two decimal numbers.
     * @param x The minuend.
     * @param y The subtrahend.
     * @return The difference of x and y.
     */
    public static Double sub(Double x, Double y) {
        return x - y;
    }

    /**
     * Multiplies two integers.
     * @param x The first factor.
     * @param y The second factor.
     * @return The product of x and y.
     */
    public static Integer mul(Integer x, Integer y) {
        return mul(x.doubleValue(), y.doubleValue()).intValue();
    }

    /**
     * Multiplies an integer and a decimal number.
     * @param x The first factor.
     * @param y The second factor.
     * @return The product of x and y.
     */
    public static Double mul(Integer x, Double y) {
        return mul(x.doubleValue(), y);
    }

    /**
     * Multiplies a decimal number and an integer.
     * @param x The first factor.
     * @param y The second factor.
     * @return The product of x and y.
     */
    public static Double mul(Double x, Integer y) {
        return mul(x, y.doubleValue());
    }

    /**
     * Multiplies two decimal numbers.
     * @param x The first factor.
     * @param y The second factor.
     * @return The product of x and y.
     */
    public static Double mul(Double x, Double y) {
        return x * y;
    }

    /**
     * Divides two integers.
     * @param x The dividend.
     * @param y The divisor.
     * @return The quotient of x and y.
     */
    public static Double div(Integer x, Integer y) {
        return div(x.doubleValue(), y.doubleValue());
    }

    /**
     * Divides an integer by a decimal number.
     * @param x The dividend.
     * @param y The divisor.
     * @return The quotient of x and y.
     */
    public static Double div(Integer x, Double y) {
        return div(x.doubleValue(), y);
    }

    /**
     * Divides a decimal number by an integer.
     * @param x The dividend.
     * @param y The divisor.
     * @return The quotient of x and y.
     */
    public static Double div(Double x, Integer y) {
        return div(x, y.doubleValue());
    }

    /**
     * Divides two decimal numbers.
     * @param x The dividend.
     * @param y The divisor.
     * @return The quotient of x and y.
     */
    public static Double div(Double x, Double y) {
        if (y.equals(0.0)) {
            throw new ArithmeticException("Division by zero.");
        }

        return x / y;
    }

    /**
     * Calculates the factorial of a given number.
     * @param x The number for which the factorial is calculated.
     * @return The factorial of the number x.
     */
    public static Integer factorial(Integer x) {
        int factorial = 1;

        for (int i = x; i > 1; --i) {
            factorial = factorial * i;
        }

        return factorial;
    }

    /**
     * Calculates the power of a given number.
     * @param x The base of the power.
     * @param y The exponent.
     * @return The power of the number x to y.
     */
    public static Integer power(Integer x, Integer y) {
        return power(x.doubleValue(), y).intValue();
    }

    /**
     * Calculates the power of a given number.
     * @param x The base of the power.
     * @param y The exponent.
     * @return The power of the number x to y.
     */
    public static Double power(Double x, Integer y) {
        if (y < 0) {
            throw new ArithmeticException("Exponent is not natural number.");
        }

        if (y.equals(0)) {
            return 1.0;
        }

        if (y.equals(1)) {
            return x;
        }
        Double result = x;

        for (int i = 0; i < y - 1; i++) {
            result *= x;
        }

        return result;
    }

    /**
     * Calculates the root of a given number.
     * @param x The number from which the root is calculated.
     * @param y The degree of the root.
     * @return The root of the number x to y.
     */
    public static Double root(Integer x, Integer y) {
        return root(x.doubleValue(), y);
    }

    /**
     * Calculates the root of a given number.
     * @param x The number from which the root is calculated.
     * @param y The degree of the root.
     * @return The root of the number x to y.
     */
    public static Double root(Double x, Integer y) {
        if (y == 0) {
            throw new ArithmeticException("0th root is not defined.");
        }
        if (x < 0 && mod(y, 2) == 0) {
            throw new ArithmeticException("The even root of negative number is not real number.");
        }

        return Math.pow(x, 1.0 / y);
    }

    /**
     * Calculates the absolute value of an integer.
     * @param x The number for which the absolute value is calculated.
     * @return The absolute value of the number x.
     */
    public static Integer abs(Integer x) {
        return abs(x.doubleValue()).intValue();
    }

    /**
     * Calculates the absolute value of a decimal number.
     * @param x The number for which the absolute value is calculated.
     * @return The absolute value of the number x.
     */
    public static Double abs(Double x) {
        if (x < 0.0) {
            x = -x;
        }

        return x;
    }

    /**
     * Calculates the remainder of dividing two integers.
     * @param x The dividend.
     * @param y The divisor.
     * @return The remainder of dividing x by y.
     */
    public static Integer mod(Integer x, Integer y) {
        return mod(x.doubleValue(), y.doubleValue()).intValue();
    }

    /**
     * Calculates the remainder of dividing an integer by a decimal number.
     * @param x The dividend.
     * @param y The divisor.
     * @return The remainder of dividing x by y.
     */
    public static Double mod(Integer x, Double y) {
        return mod(x.doubleValue(), y);
    }

    /**
     * Calculates the remainder of dividing a decimal number by an integer.
     * @param x The dividend.
     * @param y The divisor.
     * @return The remainder of dividing x by y.
     */
    public static Double mod(Double x, Integer y) {
        return mod(x, y.doubleValue());
    }

    /**
     * Calculates the remainder of dividing two decimal numbers.
     * @param x The dividend.
     * @param y The divisor.
     * @return The remainder of dividing x by y.
     */
    public static Double mod(Double x, Double y) {
        if (y.equals(0.0)) {
            throw new ArithmeticException("sDivision by zero.");
        }

        return x % y;
    }

}
