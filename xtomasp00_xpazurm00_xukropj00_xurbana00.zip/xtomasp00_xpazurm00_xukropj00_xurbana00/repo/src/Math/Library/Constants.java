/********************************************
 * Název projektu: Calculator
 * Balíček: Math.Library
 * Soubor: Constants.java
 * Datum: 17.4.2024
 * Poslední  změna: 17.4.2024
 * Autor: xpazurm00
 *
 * Popis: Třída s matematickými konstantami
 *
 ********************************************/
/**
 * @file Constants.java
 *
 * @brief Class containing commonly used mathematical constants
 * @author xpazurm00
 */
package Math.Library;

public class Constants {
     public static final double PI = Math.PI;
     public static final double E = Math.E;
     public static final double EPSILON = 0.00000000001;
}
