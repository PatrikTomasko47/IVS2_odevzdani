/******************************************************
 * Název projektu: Calculator
 * Soubor: Stddev.java
 * Datum: 16.4.2023
 * Poslední  změna: 17.4.2024
 * Autor: xtomasp00
 *
 * Popis: Vypocet smerodatne odchylky pro profiling
 *
 ******************************************************/
/**
 * @file Stddev.java
 *
 * @brief Calculation of standart deviation for profiling
 * @author xtomasp00
 */
package Stddev;

import Math.Library.MathOperations;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class Stddev{
    /**
     * Checks wether an input file has been provided and if yes, stores the values in list of doubles, the calculates the standart deviation with the provided values
     *
     * @brief Checks and stores the input data, calculates the standart deviation with the provided valuse
     * @param args contains the arguments of the code
     */
    public static void main(String[] args){
        if(args.length != 1){
            System.out.println("Too many or no input file has been given. Make sure you have given one input file with the test data.");
            return;
        }
        ArrayList<Double> Data = new ArrayList<Double>();
        /**
         * Attempts to open the file provided and goes through lines and splits them to the singular values and stores them one by one in the list of doubles Data
         * @brief extraction of the data from the input file
         */
        try {
            File Input = new File(args[0]);
            Scanner Reader = new Scanner(Input);
            while (Reader.hasNextLine()){ //Itterating through the lines.
                String line = Reader.nextLine();
                if(!line.isEmpty()) { //Checks wether the line contains anyting.
                    String[] CurLine = line.split(" ");
                    for(int i = 0; i < CurLine.length; i++) { //Itterating through the singular values of the line and inserting them into the list
                        try {
                            Data.add(Double.parseDouble(CurLine[i]));//Checking wether the insertion is executed correctly.
                        } catch (Error error) {
                            System.out.println("An error has occured during the itteration through input data, make sure all line have numbers, nothing else.");
                            return;
                        }
                    }
                }
            }
            Reader.close();
        } catch (FileNotFoundException error){ //Checking for an error caused by the file not existing
            System.out.println("The file you provided does not exist.");
            return;
        }
        /**
         * @brief Calculation of the standart deviation
         * Checks wether any values were extracted from the files and then calculates the standart deviation
         */
        if(Data.size() <= 0){
            System.out.println("An error has occured during the itteration through the input file.");
        }else{
            //Setting up the variables for the calculation
            double average = 0;
            double result = 0;
            for(int i = 0; i < Data.size(); i++){   //Calculating the average of the values
                average = MathOperations.add(average, Data.get(i));
            }
            average = MathOperations.div(average, Data.size());
            for(int i = 0; i < Data.size(); i++){   //Calculating the main part of the standart deviation
                double temp = MathOperations.sub(Data.get(i), average);
                temp = MathOperations.power(temp, 2);
                result = MathOperations.add(result, temp);
            }
            result = MathOperations.div(result, MathOperations.sub(Data.size(),1));
            result = MathOperations.root(result, 2);
            System.out.println(result);
        }
    }
}
